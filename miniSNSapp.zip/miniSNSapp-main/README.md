# miniSNSapp
社内SNSアプリの作成
