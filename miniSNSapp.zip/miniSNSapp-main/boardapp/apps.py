from django.apps import AppConfig


class BoardappConfig(AppConfig):
    name = 'boardapp'
